from django.contrib import admin
from .models import Order, Offer, Negotiation

admin.site.register(Order)
admin.site.register(Offer)
admin.site.register(Negotiation)
